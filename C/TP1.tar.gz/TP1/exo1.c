#include <stdio.h>
/*
Exo1.1
int   main(void)
{
  int a,b,c;
  
  printf("a = %i\n", a);
  printf("b = %i\n", b);
  printf("c = %i\n", c);

}
*/

/*
Exo1.2
int   main(void)
{
  int a,b,c;

  a = 10;
  b = 5;
  c = a + b;

  printf("a = %i\n", a);
  printf("b = %i\n", b);
  printf("c = %i\n", c);
}
*/

/*
Exo1.3
int   main(void)
{
  float x,y;

  x = 7.5;
  y = 3.2;
  printf("Somme = %d\n", x + y);
  printf("Soustraction = %d\n", x - y);
  printf("Multiplication = %d\n", x * y);
  printf("Division = %d\n", x / y);
}
*/

/*
Exo1.4
int   main(void)
{
  float x, y;

  scanf("Entrez une valeur de x : %d\n", &x);
  scanf("Entrez une valeur de y : %d\n", &y);

  printf("Somme = %d\n", x + y);
  printf("Soustraction = %d\n", x - y);
  printf("Multiplication = %d\n", x * y);
  printf("Division = %d\n", x / y);

}
*/
